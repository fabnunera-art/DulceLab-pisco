DULCELAB — página web
========================
Archivos:
- index.html
- assets/logo-dulcelab.png
- assets/icon-dulcelab.png

Funciones:
- Catálogo con Peruano, Saludable, Adultos y Night Lab Experience.
- Productos ficticios de S/ 5 a S/ 6.
- Botones para agregar productos.
- Formulario de pedido.
- El formulario abre WhatsApp al número 924 461 577 con el pedido preparado.

Para publicarla en Render:
1. Sube estos archivos a un repositorio.
2. Crea un servicio Static Site.
3. Usa el directorio raíz y publica index.html.
